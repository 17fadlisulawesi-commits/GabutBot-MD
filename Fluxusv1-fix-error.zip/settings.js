global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['62']

//================================//
// Global Mess
//================================//
global.mess = {
  owner: '❌ This command is only for the *owner*!',
  premium: '💎 This feature is only available for *premium users*!',
  group: '👥 This feature can only be used in *group chats*!',
}